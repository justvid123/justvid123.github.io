QUEST LOG — Android Home Screen App

WHAT I CHANGED
- Converted the original Quest Log HTML into a PWA.
- Replaced Claude's window.storage with browser localStorage, so your quests/progress can save normally.
- Added an installable app manifest.
- Added an offline service worker.
- Added Android-friendly app icons.
- Renamed the main page to index.html.

IMPORTANT
A real PWA installation needs to be opened from an HTTPS website. Opening index.html directly from a file manager is not the same as installing a PWA.

EASIEST WAY TO PUT IT ON YOUR PHONE
1. Upload the contents of this folder to any static HTTPS web host.
2. Open the resulting website in Chrome on your Android phone.
3. Open Chrome's ⋮ menu.
4. Choose "Install app" or "Add to Home screen" (the wording can vary).
5. Add Quest Log to your home screen.
6. After installation, open Quest Log from its icon like a normal app.

FILES
- index.html       Main game/app
- manifest.json    App installation information
- sw.js            Offline caching
- icon-192.png     App icon
- icon-512.png     App icon
